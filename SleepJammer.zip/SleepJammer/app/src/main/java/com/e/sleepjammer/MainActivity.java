package com.e.sleepjammer;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.e.sleepjammer.utils.RAdapter;
import com.neurosky.AlgoSdk.NskAlgoDataType;
import com.neurosky.AlgoSdk.NskAlgoSdk;
import com.neurosky.AlgoSdk.NskAlgoSignalQuality;
import com.neurosky.AlgoSdk.NskAlgoState;
import com.neurosky.AlgoSdk.NskAlgoType;
import com.neurosky.connection.ConnectionStates;
import com.neurosky.connection.DataType.MindDataType;
import com.neurosky.connection.TgStreamHandler;
import com.neurosky.connection.TgStreamReader;

import java.io.IOError;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import static com.neurosky.AlgoSdk.NskAlgoSdk.NskAlgoUninit;
import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {
    private final static int REQUEST_ENABLE_BT = 1111;

    private final static String TAG = "MainActivity";
    public static BluetoothDevice selectedDevice;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter rAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private BluetoothAdapter mBluetoothAdapter;
    private ArrayList<BluetoothDevice> myDiscoveredBT = new ArrayList<BluetoothDevice>();
    private ArrayList<BluetoothDevice> mypairedBT = new ArrayList<>();

    private NskAlgoSdk nskAlgoSdk;
    
    private ImageView loadingImage;
    private LinearLayout loadingLayout;
    private TextView concentrationValue, meditationValue,bpmValue,alphaValue,betaValue,thetaValue,deltaValue,gammaValue;
    private TextView sqText,stateText,deviceName,deviceUUID,deviceStatus;
    private Switch sound,vibrate;
    private Button btnStart;
    private Button btnStop;

    private Ringtone ringtone;
    private Vibrator vibrator;

    private Boolean ring , vibration;

    private final double REQUIREDTHETA = 6.0 ;
    private final double REQUIREDBETA = 14.0 ;
    private final int REQUIREDEYECLOSED = 20 ;


    private TgStreamReader tgStreamReader;

    private short raw_data[] = {0};
    private int raw_data_index= 0;

    private double totaltheta = 0.00000;
    private double totaldelta = 0.00000;

    private int a = 0;

    private HashMap<String, Double> datacheck = new HashMap();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
        }
        setContentView(R.layout.activity_main);
        init();

        bluetoothCheck();
        pairedBTCheck();

        nskAlgoSdk = new NskAlgoSdk();

        nskAlgoSdkprocess();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        nskAlgoSdk.NskAlgoPause();
        super.onPause();
    }

    private void init() {
        loadingImage = findViewById(R.id.loadingImage);
        loadingLayout = findViewById(R.id.loadinglayout);
        recyclerView = findViewById(R.id.recyclerView);
        concentrationValue =findViewById(R.id.concentrationValue);
        meditationValue = findViewById(R.id.meditationValue);
        bpmValue = findViewById(R.id.bpmValue);;
        betaValue = findViewById(R.id.betaValue);
        alphaValue = findViewById(R.id.alphaValue);
        thetaValue = findViewById(R.id.thetaValue);
        deltaValue = findViewById(R.id.deltaValue);
        gammaValue = findViewById(R.id.gammaValue);
        sqText = findViewById(R.id.sqText);
        stateText = findViewById(R.id.stateText);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        deviceName = findViewById(R.id.deviceName);
        deviceUUID = findViewById(R.id.deviceUUID);
        deviceStatus = findViewById(R.id.deviceStatus);
        sound = findViewById(R.id.sound);
        vibrate = findViewById(R.id.vibrate);
        ring = true;
        vibration = true;
        datacheck.put("THETA",0.0);
        datacheck.put("BETA",0.0);
        datacheck.put("EYE",0.0);
        recyclerViewMethod();
        setonclick();
    }

    private void setonclick(){
        sound.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ring= true;
                    //Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                    //r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                    //r.play
                }else{
                    ring=false;
                }
            }
        });

        vibrate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    vibration = true;
                }else{
                    vibration = false;
                }
                Log.d(TAG, " Average Theta : "+totaltheta/5);
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);
                if(ring){
                    Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                    ringtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
                }
                if(vibration){
                    vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                }

               startprocessing();
                Log.d(TAG,"start");
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    NskAlgoSdk.NskAlgoPause();
                    btnStart.setEnabled(true);
                    btnStop.setEnabled(false);
                    Log.d(TAG,"stoped");
                }catch (IOError e){
                    Log.d("TAG",e+"");
                }
            }
        });

    }

    private void startprocessing(){
        nskAlgoSdk.NskAlgoStart(false);

        raw_data = new short[512];
        raw_data_index = 0;
        tgStreamReader = new TgStreamReader(mBluetoothAdapter,callback);

        if(tgStreamReader != null && tgStreamReader.isBTConnected()){

            // Prepare for connecting
            tgStreamReader.stop();
            tgStreamReader.close();
        }

        tgStreamReader.connect();

        Log.d(TAG,"started");
    }

    private void nskAlgoSdkprocess(){
        nskAlgoSdk.setOnStateChangeListener(new NskAlgoSdk.OnStateChangeListener() {
            @Override
            public void onStateChange(int state, int reason) {
                String stateStr = "";
                String reasonStr = "";
                for (NskAlgoState s : NskAlgoState.values()) {
                    if (s.value == state) {
                        stateStr = s.toString();
                    }
                }
                for (NskAlgoState r : NskAlgoState.values()) {
                    if (r.value == reason) {
                        reasonStr = r.toString();
                    }
                }
                final String finalStateStr = stateStr + " | " + reasonStr;
                final int finalState = state;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // change UI elements here
                        stateText.setText(finalStateStr);

                        if (finalState == NskAlgoState.NSK_ALGO_STATE_RUNNING.value || finalState == NskAlgoState.NSK_ALGO_STATE_COLLECTING_BASELINE_DATA.value) {
                            btnStart.setText("Start");
                            btnStart.setEnabled(false);
                            btnStop.setEnabled(true);
                        } else if (finalState == NskAlgoState.NSK_ALGO_STATE_STOP.value) {
                            btnStart.setText("Start");
                            btnStart.setEnabled(true);
                            btnStop.setEnabled(false);

                            System.gc();
                        } else if (finalState == NskAlgoState.NSK_ALGO_STATE_PAUSE.value) {
                            btnStart.setText("Start");
                            btnStart.setEnabled(true);
                            btnStop.setEnabled(false);
                        } else if (finalState == NskAlgoState.NSK_ALGO_STATE_ANALYSING_BULK_DATA.value) {
                            btnStart.setText("Start");
                            btnStart.setEnabled(false);
                            btnStop.setEnabled(true);
                        } else if (finalState == NskAlgoState.NSK_ALGO_STATE_INITED.value || finalState == NskAlgoState.NSK_ALGO_STATE_UNINTIED.value) {
                            btnStart.setText("Start");
                            btnStart.setEnabled(true);
                            btnStop.setEnabled(false);
                        }
                    }
                });
            }
        });

        nskAlgoSdk.setOnAttAlgoIndexListener(new NskAlgoSdk.OnAttAlgoIndexListener() {
            @Override
            public void onAttAlgoIndex(int i) {
                concentrationValue.setText(i+"");
            }
        });

        nskAlgoSdk.setOnMedAlgoIndexListener(new NskAlgoSdk.OnMedAlgoIndexListener() {
            @Override
            public void onMedAlgoIndex(int i) {
                meditationValue.setText(i+"");
            }
        });

        nskAlgoSdk.setOnEyeBlinkDetectionListener(new NskAlgoSdk.OnEyeBlinkDetectionListener() {
            @Override
            public void onEyeBlinkDetect(int i) {
                Log.d(TAG,"Eye : " + i);
                bpmValue.setText(i+"");
                if(i<10){
                    wakeUP("EYE",i);
                }
            }
        });
        nskAlgoSdk.setOnBPAlgoIndexListener(new NskAlgoSdk.OnBPAlgoIndexListener() {
            @Override
            public void onBPAlgoIndex(float delta, float theta, final float alpha, float beta, float gamma) {
                final float fDelta = delta, fTheta = theta, fAlpha = alpha, fBeta = beta, fGamma = gamma;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        Log.d(TAG,"ALPHA :"+fAlpha);
                        Log.d(TAG,"BETA :"+fBeta);
                        Log.d(TAG,"Delta :"+fDelta);
                        Log.d(TAG,"Theta :"+fTheta);
                        Log.d(TAG,"Gamma :"+fGamma);
                        average(fTheta,fDelta);
                        alphaValue.setText(fAlpha+"");
                        betaValue.setText(fBeta+"");
                        deltaValue.setText(fDelta+"");
                        thetaValue.setText(fTheta+"");
                        gammaValue.setText(fGamma+"");

                        if(fTheta < REQUIREDTHETA){
                            wakeUP("THETA",fTheta);
                        }else if (fBeta > REQUIREDBETA){
                            wakeUP("BETA",fBeta);

                        }
                    }
                });
            }
        });

        nskAlgoSdk.setOnSignalQualityListener(new NskAlgoSdk.OnSignalQualityListener() {
            @Override
            public void onSignalQuality(final int level) {
                final int fLevel = level;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String sqStr = NskAlgoSignalQuality.values()[level].toString();
                        sqText.setText(sqStr);
                    }
                });
            }
        });
    }

    private void wakeUP(String valueOf, double a){
        if(valueOf.equals("BETA")){
            if (a>datacheck.get("BETA")){
                datacheck.put("BETA",a);
                Log.d(TAG,"new Beta :"+a);
            }
        }else if(datacheck.get(valueOf)>a){
            datacheck.put(valueOf,a);
            Log.d(TAG,valueOf+":"+a);
        }else{
            return;
        }
            ringtone.stop();
            vibrator.cancel();
            ringtone.play();
            vibrator.vibrate(1000);
    }


    private void average(double fTheta,double fDelta){
        totaltheta = totaltheta+fTheta;
        totaldelta = totaldelta+fDelta;
        a++;
        Log.d(TAG,"//////////");
        if(a==5){
            Log.d(TAG, " Average Theta : "+totaltheta/5);
            Log.d(TAG, " Average Delta : "+totaldelta/5);
            totaldelta = 0.0000;
            totaltheta = 0.0000;
            a = 0;
        }
    }

    private TgStreamHandler callback = new TgStreamHandler() {

        @Override
        public void onDataReceived(int datatype, int data, Object obj) {
            switch (datatype) {
                case MindDataType.CODE_ATTENTION:
                    short attValue[] = {(short)data};
                    nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_ATT.value, attValue, 1);
                    break;
                case MindDataType.CODE_MEDITATION:
                    short medValue[] = {(short)data};
                    nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_MED.value, medValue, 1);
                    break;
                case MindDataType.CODE_POOR_SIGNAL:
                    short pqValue[] = {(short)data};
                    nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_PQ.value, pqValue, 1);
                    break;
                case MindDataType.CODE_RAW:
                    raw_data[raw_data_index++] = (short)data;
                    if (raw_data_index == 512) {
                        nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_EEG.value, raw_data, raw_data_index);
                        raw_data_index = 0;
                    }
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onStatesChanged(int connectionStates) {
            // TODO Auto-generated method stub
            switch (connectionStates) {
                case ConnectionStates.STATE_CONNECTING:
                    deviceStatus.setText(R.string.connecting);
                    deviceStatus.setBackgroundResource(R.drawable.connecting_background);
                    // Do something when connecting
                    break;
                case ConnectionStates.STATE_CONNECTED:
                    // Do something when connected
                    tgStreamReader.start();
                    showToast("Connection to Neurosky Mindwave Mobile successful", Toast.LENGTH_SHORT);
                    deviceStatus.setText(R.string.connected);
                    deviceStatus.setBackgroundResource(R.drawable.connect_background);
                    break;
                case ConnectionStates.STATE_WORKING:
                    // Do something when working

                    //(9) demo of recording raw data , stop() will call stopRecordRawData,
                    //or you can add a button to control it.
                    //You can change the save path by calling setRecordStreamFilePath(String filePath) before startRecordRawData
                    //tgStreamReader.startRecordRawData();

                    break;
                case ConnectionStates.STATE_GET_DATA_TIME_OUT:
                    // Do something when getting data timeout

                    //(9) demo of recording raw data, exception handling
                    //tgStreamReader.stopRecordRawData();
                    Log.d(TAG, "time out");
                    showToast("Get data time out!", Toast.LENGTH_SHORT);
                    deviceStatus.setText(getString(R.string.get_data_time_out));
                    if(tgStreamReader != null && tgStreamReader.isBTConnected()){

                        // Prepare for connecting
                        tgStreamReader.stop();
                        tgStreamReader.close();
                    }

                    break;
                case ConnectionStates.STATE_STOPPED:
                    Log.d(TAG,"TG stopped");
                    // Do something when stopped
                    // We have to call tgStreamReader.stop() and tgStreamReader.close() much more than
                    // tgStreamReader.connectAndstart(), because we have to prepare for that.

                    break;
                case ConnectionStates.STATE_DISCONNECTED:
                    deviceStatus.setText(R.string.disconnected);
                    deviceStatus.setBackgroundResource(R.drawable.disconnect_background);
                    // Do something when disconnected
                    break;
                case ConnectionStates.STATE_ERROR:

                    Log.d(TAG,"TG error");
                    // Do something when you get error message
                    break;
                case ConnectionStates.STATE_FAILED:

                    MainActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            String statefailed = getString(R.string.failed)+" "+ getString(R.string.try_again);
                            deviceStatus.setText(statefailed);
                            deviceStatus.setBackgroundResource(R.drawable.disconnect_background);
                        }

                    });
                    // Do something when you get failed message
                    // It always happens when open the BluetoothSocket error or timeout
                    // Maybe the device is not working normal.
                    // Maybe you have to try again
                    break;
            }
        }

        @Override
        public void onChecksumFail(byte[] bytes, int i, int i1) {

        }

        @Override
        public void onRecordFail(int i) {
            Log.e(TAG,"onRecordFail: " +i);
        }

    };

    private void recyclerViewMethod() {
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
    }

    public void scanning(View v) {
        selectedDevice = null;
        myDiscoveredBT.clear();
        if (mBluetoothAdapter.isDiscovering()) {
            mBluetoothAdapter.cancelDiscovery();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkBTPermissions();
        }
        mBluetoothAdapter.startDiscovery();
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(receiver, filter);
        loadingLayout.setVisibility(View.VISIBLE);
        Animation aniRotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.loading_animation);
        loadingImage.startAnimation(aniRotate);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    sleep(5000);
                    loadingLayout.setVisibility(View.INVISIBLE);
                    mBluetoothAdapter.cancelDiscovery();
                    unregisterReceiver(receiver);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void connect(View v) {
        Boolean found = false;
        if (selectedDevice == null) {
            Toast.makeText(getApplicationContext(), getString(R.string.not_selected), Toast.LENGTH_LONG).show();
            return;
        }
        if (mypairedBT.size() > 0) {
            int index = 0;
            while (index < mypairedBT.size()) {
                if (selectedDevice.getAddress().equals(mypairedBT.get(index).getAddress())) {
                    found = true;

                    break;
                }
                index++;
            }
        }

        if (found) {
            deviceName.setText(selectedDevice.getName());
            deviceUUID.setText(selectedDevice.getUuids()+"");
            int algoTypes = 0;

            algoTypes += NskAlgoType.NSK_ALGO_TYPE_MED.value;

            algoTypes += NskAlgoType.NSK_ALGO_TYPE_ATT.value;

            algoTypes += NskAlgoType.NSK_ALGO_TYPE_BLINK.value;

            algoTypes += NskAlgoType.NSK_ALGO_TYPE_BP.value;




            int ret = nskAlgoSdk.NskAlgoInit(algoTypes, getFilesDir().getAbsolutePath());
            if(ret ==0){
                btnStart.setEnabled(true);

            }else{
                showToast(getString(R.string.couldnt_init),Toast.LENGTH_SHORT);
            }
        } else {
            alert(getString(R.string.not_paired));
        }
    }

    public void disconnect(View v){
        int ret = NskAlgoUninit();
        deviceStatus.setText("");
        Log.d(TAG,"UnIntied");
    }

    private void pairedBTCheck() {
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                mypairedBT.add(device);
            }
        }
    }

    private void bluetoothCheck() {
        try {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if (mBluetoothAdapter == null) {
                Toast.makeText(getApplicationContext(), getString(R.string.does_not_support), Toast.LENGTH_SHORT).show();
            } else if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showToast(final String msg, final int timeStyle) {
        MainActivity.this.runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), msg, timeStyle).show();
            }

        });
    }

    private void alert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intentOpenBluetoothSettings = new Intent();
                        intentOpenBluetoothSettings.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                        startActivity(intentOpenBluetoothSettings);
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkBTPermissions() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            int permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != 0) {

                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1001); //Any number
            }
        } else {
            Log.d("TAG", "checkBTPermissions: No need to check permissions. SDK version < LOLLIPOP.");
        }
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                //Discovery has found a device. Get the BluetoothDevice
                // object and its info from the Intent.
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device.getName() != null) {
                    myDiscoveredBT.add(device);
                }
            } else {
                Toast.makeText(getApplicationContext(), getString(R.string.try_again), Toast.LENGTH_SHORT).show();
            }
            rAdapter = new RAdapter(myDiscoveredBT);
            recyclerView.setAdapter(rAdapter);
        }
    };

    @Override
    public void onBackPressed() {
        nskAlgoSdk.NskAlgoUninit();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

}