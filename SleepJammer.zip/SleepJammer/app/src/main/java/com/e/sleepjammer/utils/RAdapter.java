package com.e.sleepjammer.utils;

import android.bluetooth.BluetoothDevice;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.e.sleepjammer.MainActivity;
import com.e.sleepjammer.R;

import java.util.ArrayList;

public class RAdapter extends RecyclerView.Adapter<RAdapter.MyViewHolder>{
   private ArrayList<BluetoothDevice> mDataset;


    public static class MyViewHolder extends  RecyclerView.ViewHolder{
        public TextView deviceName;
        public TextView deviceUUID;
        
        public MyViewHolder(View v) {
            super(v);
            deviceName = (TextView) v.findViewById(R.id.deviceName);
            deviceUUID = (TextView) v.findViewById(R.id.deviceAddress);
        }
    }

    public RAdapter(ArrayList<BluetoothDevice> myDataset){
        mDataset = myDataset;
    }

    @Override
    public RAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v =  LayoutInflater.from(parent.getContext()).inflate(R.layout.bluetooth_device_view,parent,false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final RAdapter.MyViewHolder holder, int position) {
        holder.deviceName.setText(mDataset.get(position).getName());
        holder.deviceUUID.setText(mDataset.get(position).getAddress());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.selectedDevice=mDataset.get(holder.getAdapterPosition());
                holder.itemView.setBackgroundResource(R.drawable.connect_background);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}

